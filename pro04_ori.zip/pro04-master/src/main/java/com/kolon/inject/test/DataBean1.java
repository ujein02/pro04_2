package com.kolon.inject.test;

public class DataBean1 {

}
