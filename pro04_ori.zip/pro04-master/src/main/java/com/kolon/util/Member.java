package com.kolon.util;

import lombok.Data;

@Data
public class Member {
	private String id; 
	private String pw; 
}