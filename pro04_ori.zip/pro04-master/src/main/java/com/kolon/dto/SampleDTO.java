package com.kolon.dto;

import lombok.Data;

@Data	// getter setter constructor 
public class SampleDTO {
	private String name;
	private int age;
	private double iq;

}
