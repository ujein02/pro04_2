package com.kolon.dto;

import lombok.Data;

@Data
public class FreeDTO {
	private int fno;
	private String title;
	private String content;
	private String regdate;
	private int visited;
	private String id;
	private int rec;

}
